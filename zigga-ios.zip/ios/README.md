# ZIGGA VPN — iOS

SwiftUI-клиент с тем же дизайном, что Android-версия: ввод 6-значного кода, запрос к вашему
API на Vercel, получение персонального конфига и подключение туннеля.

VPN-движок — **тот же, что в APK: AmneziaWG** (`amneziawg-apple` → `WireGuardKit`,
userspace `amneziawg-go`). Расширение — `NEPacketTunnelProvider`.

## Адрес API

Уже прописан: `https://v0-telegram-vpn-bot-iota.vercel.app`
(ключ `ZIGGA_API_BASE` в `ios/Config/ZIGGA-Info.plist`).

## Контракт API

```
POST {ZIGGA_API_BASE}/api/app/login
Content-Type: application/json

{"pin":"123456"}
```

Успех `200`:

```json
{
  "ok": true,
  "brand": "ZIGGA",
  "user": {"nickname": "...", "telegram_id": 123456789},
  "balance": 150,
  "subscription": {"active": true, "expires_at": "...", "seconds_left": 864000, "days_left": 10},
  "config": {"name": "...", "filename": "...", "type": "amneziawg", "content": "[Interface]..."},
  "config_error": null
}
```

Ошибки: `400 invalid_pin_format`, `401 wrong_pin`, `429 too_many_attempts`.

Если `config` = `null`, приложение показывает причину из `config_error`:
`no_device` — нет устройства, `subscription_expired` — подписка закончилась.

PIN хранится только в **Keychain** (`ios/ZIGGA/Keychain.swift`), конфиг — в App Group,
чтобы его видело расширение. При каждом запуске приложение повторяет запрос и обновляет
баланс/подписку/конфиг.

Bundle ID: приложение `com.zigga.vpn`, расширение `com.zigga.vpn.tunnel`,
App Group `group.com.zigga.vpn`.

## Сборка без Mac (GitHub Actions)

Workflow: `.github/workflows/ios-unsigned-ipa.yml`, запускается на `macos-latest`.

Что он делает:

1. ставит Go 1.26 и XcodeGen;
2. клонирует `amneziawg-apple` (тег `v3.1.4`) и собирает `libwg-go.a` под `iphoneos/arm64`;
3. `xcodegen generate` в папке `ios`;
4. `xcodebuild ... CODE_SIGNING_ALLOWED=NO` (подпись не нужна);
5. упаковывает `Payload/ZIGGA.app` в `ZIGGA-unsigned.ipa` + `.sha256`;
6. кладёт `.ipa` в артефакты и, если это GitHub Release, прикрепляет к релизу.

Запуск: вкладка **Actions** → **iOS unsigned IPA** → **Run workflow**.

Скачать: артефакт `ZIGGA-unsigned-ipa` в завершённом запуске (или файл из Releases).

## Подпись своим сервисом

`.ipa` неподписанный. Для переподписи нужны:

- Bundle ID приложения — `com.zigga.vpn`;
- Bundle ID расширения — `com.zigga.vpn.tunnel`;
- entitlements приложения (`ios/Config/ZIGGA.entitlements`) — App Group;
- entitlements расширения (`ios/Config/Tunnel.entitlements`) —
  `com.apple.developer.networking.networkextension = packet-tunnel-provider` + App Group.

**Важно:** сертификат должен включать entitlement Network Extension, иначе iOS поставит
приложение, но туннель не запустится (ошибка при включении). Это ограничение Apple,
а не кода.

## Локально (если появится Mac)

```bash
brew install xcodegen go
git clone --depth 1 --branch v3.1.4 https://github.com/amnezia-vpn/amneziawg-apple.git ios/Vendor/amneziawg-apple
make -C ios/Vendor/amneziawg-apple/Sources/WireGuardKitGo build \
  PLATFORM_NAME=iphoneos ARCHS=arm64 SDKROOT="$(xcrun --sdk iphoneos --show-sdk-path)"
cd ios && xcodegen generate && open ZIGGA.xcodeproj
```

## Что не проверено

- Реальная сборка в CI ещё не запускалась (первый прогон — ваш).
- Живое рукопожатие AmneziaWG с вашим сервером на iPhone не проверялось: в этом окружении
  нет macOS/Xcode и устройства.
- Экран рисуется по коду Android-версии; визуальная сверка на iPhone не делалась.
