import Foundation

// MARK: - Модели ответа

struct LoginResponse: Codable {
    let ok: Bool
    let brand: String?
    let user: User?
    let balance: Double?
    let subscription: Subscription?
    let config: RemoteConfig?
    let configError: String?

    struct User: Codable {
        let nickname: String?
        let telegramId: Int64?
    }

    struct Subscription: Codable {
        let active: Bool?
        let expiresAt: String?
        let secondsLeft: Int?
        let daysLeft: Int?
    }

    struct RemoteConfig: Codable {
        let name: String?
        let filename: String?
        let type: String?
        let content: String?
    }
}

enum ApiError: LocalizedError {
    case notConfigured
    case invalidPinFormat
    case wrongPin
    case tooManyAttempts
    case network
    case badResponse
    case server(String)

    var errorDescription: String? {
        switch self {
        case .notConfigured:
            return "Не задан адрес API. Проверьте ZIGGA_API_BASE в Info.plist"
        case .invalidPinFormat:
            return "Пароль должен состоять из 6 цифр"
        case .wrongPin:
            return "Неверный пароль"
        case .tooManyAttempts:
            return "Слишком много попыток. Попробуйте через 15 минут"
        case .network:
            return "Нет связи с сервером. Проверьте интернет"
        case .badResponse:
            return "Сервер вернул неожиданный ответ"
        case .server(let message):
            return message
        }
    }
}

// MARK: - Клиент

/// POST {base}/api/app/login  {"pin":"123456"}
final class ApiClient {
    static let shared = ApiClient()

    private let session: URLSession
    private let decoder: JSONDecoder

    private init() {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: configuration)

        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        self.decoder = decoder
    }

    var baseURL: String {
        if let override = UserDefaults.standard.string(forKey: ZConst.apiBaseOverrideKey), !override.isEmpty {
            return trimSlashes(override)
        }
        let value = Bundle.main.object(forInfoDictionaryKey: "ZIGGA_API_BASE") as? String ?? ""
        return trimSlashes(value)
    }

    func login(pin: String, completion: @escaping (Result<LoginResponse, ApiError>) -> Void) {
        guard baseURL.lowercased().hasPrefix("http"),
              let url = URL(string: baseURL + "/api/app/login") else {
            completion(.failure(.notConfigured))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: ["pin": pin])
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("ZIGGA-iOS/1.0", forHTTPHeaderField: "User-Agent")
        request.setValue("no-store", forHTTPHeaderField: "Cache-Control")

        session.dataTask(with: request) { [weak self] data, response, error in
            guard let self = self else { return }
            guard error == nil, let http = response as? HTTPURLResponse else {
                completion(.failure(error == nil ? .badResponse : .network))
                return
            }
            let payload = data ?? Data()

            if http.statusCode == 200,
               let login = try? self.decoder.decode(LoginResponse.self, from: payload),
               login.ok {
                completion(.success(login))
                return
            }

            let envelope = try? self.decoder.decode(Envelope.self, from: payload)
            completion(.failure(self.mapError(
                code: envelope?.error,
                message: envelope?.message,
                status: http.statusCode
            )))
        }.resume()
    }

    // MARK: - Private

    private struct Envelope: Codable {
        let ok: Bool?
        let error: String?
        let message: String?
    }

    private func mapError(code: String?, message: String?, status: Int) -> ApiError {
        switch (code ?? "").lowercased() {
        case "invalid_pin_format": return .invalidPinFormat
        case "wrong_pin": return .wrongPin
        case "too_many_attempts": return .tooManyAttempts
        default: break
        }

        switch status {
        case 400: return .invalidPinFormat
        case 401: return .wrongPin
        case 429: return .tooManyAttempts
        default: break
        }

        if let message = message, !message.isEmpty {
            return .server(message)
        }
        return .server("Сервер ответил ошибкой \(status)")
    }

    private func trimSlashes(_ value: String) -> String {
        var result = value.trimmingCharacters(in: .whitespacesAndNewlines)
        while result.hasSuffix("/") {
            result.removeLast()
        }
        return result
    }
}
