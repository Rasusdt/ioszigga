import SwiftUI

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255.0,
            green: Double((hex >> 8) & 0xFF) / 255.0,
            blue: Double(hex & 0xFF) / 255.0,
            opacity: opacity
        )
    }
}

/// Палитра из Android-версии ZIGGA.
enum Zig {
    static let background = Color(hex: 0x0B0D06)
    static let text = Color(hex: 0xF3F7EC)
    static let neon = Color(hex: 0xB4E832)
    static let gold = Color(hex: 0xE3B23C)
    static let muted = Color(hex: 0x939B87)
    static let card = Color.white.opacity(0.12)
    static let stroke = Color.white.opacity(0.15)
    static let danger = Color(hex: 0xFF6B6B)
    static let disc = Color(hex: 0x141A0E)
    static let offAccent = Color(hex: 0x8FA06E)
    static let dimRing = Color(hex: 0x2A3320)
}

struct ZigCard<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(Zig.card)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Zig.stroke, lineWidth: 1)
            )
    }
}
