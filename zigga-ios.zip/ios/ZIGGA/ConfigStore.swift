import Combine
import Foundation

/// Хранилище конфига в App Group, чтобы расширение и приложение видели одни данные.
final class ConfigStore: ObservableObject {
    static let shared = ConfigStore()

    @Published private(set) var config: String?
    @Published private(set) var label: String?

    private let defaults: UserDefaults

    init() {
        defaults = UserDefaults(suiteName: ZConst.appGroupID) ?? .standard
        config = defaults.string(forKey: ZConst.configKey)
        label = defaults.string(forKey: ZConst.labelKey)
    }

    var hasConfig: Bool { config != nil }

    func save(config: String, label: String?) {
        defaults.set(config, forKey: ZConst.configKey)
        defaults.set(label, forKey: ZConst.labelKey)
        self.config = config
        self.label = label
    }

    func clear() {
        defaults.removeObject(forKey: ZConst.configKey)
        defaults.removeObject(forKey: ZConst.labelKey)
        config = nil
        label = nil
    }

    var title: String {
        if let label = label, !label.isEmpty { return label }
        return config == nil ? "Конфиг не добавлен" : "Мой конфиг"
    }

    /// Например: «AmneziaWG · 1.2.3.4:51820»
    var summary: String {
        guard let config = config else { return "Введите 6-значный код, чтобы получить конфиг" }
        let isAmnezia = config.contains("Jc") || config.contains("H1") || config.contains("S1")
        var parts = [isAmnezia ? "AmneziaWG" : "WireGuard"]
        if let endpoint = Self.endpoint(in: config) {
            parts.append(endpoint)
        }
        return parts.joined(separator: " · ")
    }

    private static func endpoint(in config: String) -> String? {
        for line in config.components(separatedBy: .newlines) {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            guard trimmed.lowercased().hasPrefix("endpoint") else { continue }
            let parts = trimmed.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
            if parts.count == 2 {
                return String(parts[1]).trimmingCharacters(in: .whitespaces)
            }
        }
        return nil
    }
}
