import SwiftUI

struct HomeView: View {
    @ObservedObject var store: ConfigStore
    @ObservedObject var session: SessionStore
    @ObservedObject var tunnel: TunnelManager
    var onBot: () -> Void

    @State private var showLogoutConfirm = false
    @State private var actionError: String?

    private var mode: PowerButtonView.Mode {
        switch tunnel.status {
        case .connected: return .on
        case .connecting: return .connecting
        case .disconnected: return .off
        }
    }

    private var subtitle: String {
        switch tunnel.status {
        case .connected: return "Подключено · AmneziaWG"
        case .connecting: return "Подключение…"
        case .disconnected: return "AmneziaWG · WireGuard"
        }
    }

    private var subtitleColor: Color {
        switch tunnel.status {
        case .connected: return Zig.neon
        case .connecting: return Zig.gold
        case .disconnected: return Zig.muted
        }
    }

    private var statusError: String? {
        if let actionError = actionError { return actionError }
        if case .failed(let message) = session.state { return message }
        return nil
    }

    private var dotColor: Color {
        if statusError != nil { return Zig.danger }
        switch tunnel.status {
        case .connected: return Zig.neon
        case .connecting: return Zig.gold
        case .disconnected: return Color(hex: 0x7C8570)
        }
    }

    private var powerHint: String {
        switch tunnel.status {
        case .connected: return "Нажмите, чтобы отключить"
        case .connecting: return "Подключение…"
        case .disconnected: return store.hasConfig ? "Нажмите, чтобы подключиться" : "Конфиг ещё не получен"
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            header

            ZigCard {
                VStack(alignment: .leading, spacing: 6) {
                    HStack(spacing: 10) {
                        StatusDot(color: dotColor)
                        Text(store.title)
                            .font(.system(size: 15, weight: .medium))
                            .foregroundColor(Zig.text)
                            .lineLimit(1)
                        Spacer(minLength: 0)
                        if session.state == .loading {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: Zig.muted))
                        }
                    }

                    Text(store.summary)
                        .font(.system(size: 12.5))
                        .foregroundColor(Zig.muted)
                        .fixedSize(horizontal: false, vertical: true)

                    if let nickname = session.profile.nickname, !nickname.isEmpty {
                        Text("Аккаунт: \(nickname)")
                            .font(.system(size: 12.5))
                            .foregroundColor(Zig.muted)
                    }

                    HStack(spacing: 12) {
                        if let balance = session.balanceText {
                            Text(balance)
                                .font(.system(size: 12.5))
                                .foregroundColor(Zig.text)
                        }
                        Text(session.subscriptionText)
                            .font(.system(size: 12.5))
                            .foregroundColor(session.profile.subscriptionActive == true ? Zig.neon : Zig.muted)
                    }

                    if let configError = session.configErrorText {
                        Text(configError)
                            .font(.system(size: 12.5))
                            .foregroundColor(Zig.gold)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    if let error = statusError {
                        Text("Ошибка: \(error)")
                            .font(.system(size: 12.5))
                            .foregroundColor(Zig.danger)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
            .padding(.top, 20)

            Spacer(minLength: 8)

            PowerButtonView(mode: mode) {
                onPower()
            }

            Text(powerHint)
                .font(.system(size: 13))
                .foregroundColor(Zig.muted)
                .padding(.top, 6)

            Spacer(minLength: 8)

            HStack(spacing: 10) {
                Button(action: {
                    actionError = nil
                    session.refresh()
                }) {
                    Text(session.state == .loading ? "Обновляем…" : "Обновить")
                        .font(.system(size: 12.5))
                        .foregroundColor(Zig.text)
                }
                .buttonStyle(PlainButtonStyle())
                .disabled(session.state == .loading)

                Text("·").foregroundColor(Zig.muted)

                Button(action: { showLogoutConfirm = true }) {
                    Text("Выйти")
                        .font(.system(size: 12.5))
                        .foregroundColor(Color(hex: 0xA9B198))
                }
                .buttonStyle(PlainButtonStyle())
            }
            .padding(.top, 10)
            .padding(.bottom, 6)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 16)
        .alert(isPresented: $showLogoutConfirm) {
            Alert(
                title: Text("Выйти из аккаунта?"),
                message: Text("Пароль и конфиг будут удалены с устройства."),
                primaryButton: .destructive(Text("Выйти")) {
                    tunnel.disconnect()
                    session.logout()
                    actionError = nil
                },
                secondaryButton: .cancel(Text("Отмена"))
            )
        }
    }

    private var header: some View {
        HStack(spacing: 0) {
            AvatarView(size: 58)

            VStack(alignment: .leading, spacing: 2) {
                Text(session.brandTitle)
                    .font(.system(size: 22, weight: .black))
                    .foregroundColor(Zig.text)
                Text(subtitle)
                    .font(.system(size: 12))
                    .foregroundColor(subtitleColor)
            }
            .padding(.leading, 12)

            Spacer(minLength: 8)

            BotChip(action: onBot)
        }
    }

    private func onPower() {
        switch tunnel.status {
        case .connecting:
            return
        case .connected:
            tunnel.disconnect()
        case .disconnected:
            guard let config = store.config else {
                actionError = "Сначала получите конфиг: обновите данные или напишите в бота"
                return
            }
            actionError = nil
            tunnel.connect(config: config) { error in
                if let error = error {
                    actionError = error
                }
            }
        }
    }
}
