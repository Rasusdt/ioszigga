import SwiftUI

struct RootView: View {
    @StateObject private var configStore = ConfigStore.shared
    @StateObject private var session = SessionStore()
    @StateObject private var tunnel = TunnelManager()
    @State private var didBootstrap = false

    var body: some View {
        ZStack {
            ZiggaBackground()

            if session.hasPin {
                HomeView(store: configStore, session: session, tunnel: tunnel) {
                    BotLink.open()
                }
            } else {
                CodeEntryView(session: session) {
                    BotLink.open()
                }
            }
        }
        .onAppear {
            guard !didBootstrap else { return }
            didBootstrap = true
            if session.hasPin {
                session.refresh()
            }
        }
    }
}

struct RootView_Previews: PreviewProvider {
    static var previews: some View {
        RootView()
    }
}
