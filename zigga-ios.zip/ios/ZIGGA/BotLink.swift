import UIKit

enum BotLink {
    static func open() {
        let application = UIApplication.shared
        if let deepLink = URL(string: ZConst.botDeepLink), application.canOpenURL(deepLink) {
            application.open(deepLink, options: [:], completionHandler: nil)
            return
        }
        if let web = URL(string: ZConst.botWebURL) {
            application.open(web, options: [:], completionHandler: nil)
        }
    }
}
