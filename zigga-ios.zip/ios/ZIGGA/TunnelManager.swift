import Combine
import Foundation
import NetworkExtension

/// Управление VPN-профилем и Packet Tunnel расширением.
final class TunnelManager: ObservableObject {
    enum Status: Equatable {
        case disconnected
        case connecting
        case connected
    }

    @Published private(set) var status: Status = .disconnected
    @Published var lastError: String?

    private var manager: NETunnelProviderManager?
    private var observer: NSObjectProtocol?

    init() {
        observer = NotificationCenter.default.addObserver(
            forName: .NEVPNStatusDidChange,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.refreshStatus()
        }
        loadManager()
    }

    deinit {
        if let observer = observer {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    func loadManager(completion: (() -> Void)? = nil) {
        NETunnelProviderManager.loadAllFromPreferences { [weak self] managers, _ in
            DispatchQueue.main.async {
                self?.manager = managers?.first
                self?.refreshStatus()
                completion?()
            }
        }
    }

    func connect(config: String, completion: @escaping (String?) -> Void) {
        loadManager { [weak self] in
            guard let self = self else { return }
            let manager = self.manager ?? NETunnelProviderManager()
            let proto = NETunnelProviderProtocol()
            proto.providerBundleIdentifier = ZConst.tunnelBundleID
            proto.serverAddress = "ZIGGA"
            proto.providerConfiguration = ["config": config]
            manager.protocolConfiguration = proto
            manager.localizedDescription = "ZIGGA VPN"
            manager.isEnabled = true

            manager.saveToPreferences { error in
                DispatchQueue.main.async {
                    if let error = error {
                        completion(error.localizedDescription)
                        return
                    }
                    manager.loadFromPreferences { _ in
                        do {
                            try manager.connection.startVPNTunnel()
                            self.manager = manager
                            self.refreshStatus()
                            completion(nil)
                        } catch {
                            completion(error.localizedDescription)
                        }
                    }
                }
            }
        }
    }

    func disconnect() {
        manager?.connection.stopVPNTunnel()
    }

    private func refreshStatus() {
        guard let connection = manager?.connection else {
            status = .disconnected
            return
        }
        switch connection.status {
        case .connected:
            status = .connected
        case .connecting, .reasserting:
            status = .connecting
        case .disconnecting, .disconnected, .invalid:
            status = .disconnected
        @unknown default:
            status = .disconnected
        }
    }
}
