import Combine
import Foundation

struct AppProfile {
    var brand: String?
    var nickname: String?
    var balance: Double?
    var subscriptionActive: Bool?
    var daysLeft: Int?
    var expiresAt: String?
    var configError: String?
}

/// Вход по PIN + обновление данных при каждом запуске (PIN лежит в Keychain).
final class SessionStore: ObservableObject {
    enum State: Equatable {
        case idle
        case loading
        case ready
        case failed(String)
    }

    @Published private(set) var state: State = .idle
    @Published private(set) var profile = AppProfile()
    @Published private(set) var hasPin: Bool

    private let defaults: UserDefaults
    private let configStore: ConfigStore
    private static let cacheKey = "zigga.session.cache"

    init(configStore: ConfigStore = .shared) {
        self.configStore = configStore
        self.defaults = UserDefaults(suiteName: ZConst.appGroupID) ?? .standard
        self.hasPin = Keychain.pin() != nil
        loadCachedProfile()
    }

    var brandTitle: String {
        let brand = profile.brand?.uppercased()
        if let brand = brand, !brand.isEmpty {
            return "\(brand) VPN"
        }
        return "ZIGGA VPN"
    }

    var subscriptionText: String {
        guard let active = profile.subscriptionActive else { return "" }
        if !active { return "Подписка неактивна" }
        if let days = profile.daysLeft {
            return "Подписка активна · \(days) дн."
        }
        if let expires = profile.expiresAt, !expires.isEmpty {
            return "Подписка активна до \(expires)"
        }
        return "Подписка активна"
    }

    var balanceText: String? {
        guard let balance = profile.balance else { return nil }
        let rounded = (balance * 100).rounded() / 100
        let text = rounded == rounded.rounded()
            ? String(Int(rounded))
            : String(format: "%.2f", rounded)
        return "Баланс: \(text) ₽"
    }

    var configErrorText: String? {
        guard let error = profile.configError, !error.isEmpty else { return nil }
        switch error {
        case "no_device":
            return "На аккаунте нет устройства — получите его в боте"
        case "subscription_expired":
            return "Подписка закончилась — продлите в боте"
        default:
            return "Конфиг недоступен: \(error)"
        }
    }

    func login(pin: String, completion: ((String?) -> Void)? = nil) {
        state = .loading
        ApiClient.shared.login(pin: pin) { [weak self] result in
            guard let self = self else { return }
            DispatchQueue.main.async {
                switch result {
                case .failure(let error):
                    let message = error.errorDescription ?? "Не удалось войти"
                    self.state = .failed(message)
                    completion?(message)
                case .success(let response):
                    Keychain.save(pin: pin)
                    self.hasPin = true
                    self.apply(response)
                    self.state = .ready
                    completion?(nil)
                }
            }
        }
    }

    func refresh() {
        guard let pin = Keychain.pin() else {
            hasPin = false
            state = .idle
            return
        }
        state = .loading
        ApiClient.shared.login(pin: pin) { [weak self] result in
            guard let self = self else { return }
            DispatchQueue.main.async {
                switch result {
                case .failure(let error):
                    self.state = .failed(error.errorDescription ?? "Не удалось обновить данные")
                case .success(let response):
                    self.apply(response)
                    self.state = .ready
                }
            }
        }
    }

    func logout() {
        Keychain.delete()
        defaults.removeObject(forKey: Self.cacheKey)
        configStore.clear()
        profile = AppProfile()
        hasPin = false
        state = .idle
    }

    // MARK: - Private

    private func apply(_ response: LoginResponse, persist: Bool = true) {
        var newProfile = AppProfile()
        newProfile.brand = response.brand
        newProfile.nickname = response.user?.nickname
        newProfile.balance = response.balance
        newProfile.subscriptionActive = response.subscription?.active
        newProfile.daysLeft = response.subscription?.daysLeft
        newProfile.expiresAt = response.subscription?.expiresAt
        newProfile.configError = response.configError

        if let config = response.config,
           let content = config.content,
           !content.isEmpty {
            let prepared = content
                .replacingOccurrences(of: "\r\n", with: "\n")
                .replacingOccurrences(of: "\r", with: "\n")
            let label = (config.name?.isEmpty == false ? config.name : nil)
                ?? (config.filename?.isEmpty == false ? config.filename : nil)
            configStore.save(config: prepared, label: label)
        }

        profile = newProfile

        if persist {
            if let data = try? JSONEncoder().encode(CacheSnapshot(profile: newProfile, savedAt: Date())) {
                defaults.set(data, forKey: Self.cacheKey)
            }
        }
    }

    private struct CacheSnapshot: Codable {
        var brand: String?
        var nickname: String?
        var balance: Double?
        var subscriptionActive: Bool?
        var daysLeft: Int?
        var expiresAt: String?
        var configError: String?
        var savedAt: Date

        init(profile: AppProfile, savedAt: Date) {
            brand = profile.brand
            nickname = profile.nickname
            balance = profile.balance
            subscriptionActive = profile.subscriptionActive
            daysLeft = profile.daysLeft
            expiresAt = profile.expiresAt
            configError = profile.configError
            self.savedAt = savedAt
        }

        var profile: AppProfile {
            var value = AppProfile()
            value.brand = brand
            value.nickname = nickname
            value.balance = balance
            value.subscriptionActive = subscriptionActive
            value.daysLeft = daysLeft
            value.expiresAt = expiresAt
            value.configError = configError
            return value
        }
    }

    private func loadCachedProfile() {
        guard let data = defaults.data(forKey: Self.cacheKey),
              let snapshot = try? JSONDecoder().decode(CacheSnapshot.self, from: data) else {
            return
        }
        profile = snapshot.profile
    }
}
