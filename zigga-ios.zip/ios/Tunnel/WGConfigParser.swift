import Foundation
import WireGuardKit

enum WGConfigError: LocalizedError {
    case message(String)

    var errorDescription: String? {
        switch self {
        case .message(let text): return text
        }
    }
}

/// Разбор .conf в модель WireGuardKit. Поддерживает параметры AmneziaWG:
/// Jc, Jmin, Jmax, S1–S4, H1–H4, I1–I5.
enum WGConfigParser {
    static func makeTunnelConfiguration(from raw: String, name: String = "ZIGGA") throws -> TunnelConfiguration {
        let lines = raw
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")
            .components(separatedBy: "\n")

        var section = ""
        var interfaceValues: [String: String] = [:]
        var peerValues: [[String: String]] = []
        var currentPeer: [String: String] = [:]

        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if trimmed.isEmpty || trimmed.hasPrefix("#") || trimmed.hasPrefix(";") { continue }

            let lowercased = trimmed.lowercased()
            if lowercased == "[interface]" {
                section = "interface"
                continue
            }
            if lowercased == "[peer]" {
                if section == "peer", !currentPeer.isEmpty {
                    peerValues.append(currentPeer)
                }
                section = "peer"
                currentPeer = [:]
                continue
            }

            guard let equalsIndex = trimmed.firstIndex(of: "=") else { continue }
            let key = String(trimmed[trimmed.startIndex..<equalsIndex])
                .trimmingCharacters(in: .whitespaces)
                .lowercased()
            let value = String(trimmed[trimmed.index(after: equalsIndex)...])
                .trimmingCharacters(in: .whitespaces)
            if key.isEmpty || value.isEmpty { continue }

            if section == "interface" {
                interfaceValues[key] = value
            } else if section == "peer" {
                currentPeer[key] = value
            }
        }
        if section == "peer", !currentPeer.isEmpty {
            peerValues.append(currentPeer)
        }

        // MARK: Interface

        guard let privateKeyString = interfaceValues["privatekey"],
              let privateKey = PrivateKey(base64Key: privateKeyString) else {
            throw WGConfigError.message("В конфиге нет корректного PrivateKey")
        }

        var interface = InterfaceConfiguration(privateKey: privateKey)

        for address in splitList(interfaceValues["address"]) {
            if let range = IPAddressRange(from: address) {
                interface.addresses.append(range)
            }
        }
        for dns in splitList(interfaceValues["dns"]) {
            if let server = DNSServer(from: dns) {
                interface.dns.append(server)
            }
        }
        if let mtu = uint16(interfaceValues["mtu"]) { interface.mtu = mtu }
        if let port = uint16(interfaceValues["listenport"]) { interface.listenPort = port }

        // AmneziaWG-обфускация
        interface.junkPacketCount = uint16(interfaceValues["jc"])
        interface.junkPacketMinSize = uint16(interfaceValues["jmin"])
        interface.junkPacketMaxSize = uint16(interfaceValues["jmax"])
        interface.initPacketJunkSize = uint16(interfaceValues["s1"])
        interface.responsePacketJunkSize = uint16(interfaceValues["s2"])
        interface.cookieReplyPacketJunkSize = uint16(interfaceValues["s3"])
        interface.transportPacketJunkSize = uint16(interfaceValues["s4"])
        interface.initPacketMagicHeader = magicHeader(interfaceValues["h1"])
        interface.responsePacketMagicHeader = magicHeader(interfaceValues["h2"])
        interface.underloadPacketMagicHeader = magicHeader(interfaceValues["h3"])
        interface.transportPacketMagicHeader = magicHeader(interfaceValues["h4"])
        interface.specialJunk1 = interfaceValues["i1"]
        interface.specialJunk2 = interfaceValues["i2"]
        interface.specialJunk3 = interfaceValues["i3"]
        interface.specialJunk4 = interfaceValues["i4"]
        interface.specialJunk5 = interfaceValues["i5"]

        // MARK: Peers

        var peers: [PeerConfiguration] = []
        for peer in peerValues {
            guard let publicKeyString = peer["publickey"],
                  let publicKey = PublicKey(base64Key: publicKeyString) else {
                throw WGConfigError.message("В секции [Peer] нет корректного PublicKey")
            }

            var configuration = PeerConfiguration(publicKey: publicKey)

            if let presharedKeyString = peer["presharedkey"],
               let presharedKey = PreSharedKey(base64Key: presharedKeyString) {
                configuration.preSharedKey = presharedKey
            }
            if let endpointString = peer["endpoint"],
               let endpoint = Endpoint(from: endpointString) {
                configuration.endpoint = endpoint
            }
            for allowedIP in splitList(peer["allowedips"]) {
                if let range = IPAddressRange(from: allowedIP) {
                    configuration.allowedIPs.append(range)
                }
            }
            if let keepalive = peer["persistentkeepalive"] {
                configuration.persistentKeepAlive = keepalive
            }

            peers.append(configuration)
        }

        guard !peers.isEmpty else {
            throw WGConfigError.message("В конфиге нет секции [Peer]")
        }
        guard peers.contains(where: { $0.endpoint != nil }) else {
            throw WGConfigError.message("В конфиге нет Endpoint")
        }
        guard !interface.addresses.isEmpty else {
            throw WGConfigError.message("В конфиге нет Address")
        }

        return TunnelConfiguration(name: name, interface: interface, peers: peers)
    }

    // MARK: - Helpers

    private static func splitList(_ value: String?) -> [String] {
        guard let value = value else { return [] }
        return value
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }

    private static func uint16(_ value: String?) -> UInt16? {
        guard let value = value?.trimmingCharacters(in: .whitespaces), !value.isEmpty else { return nil }
        return UInt16(value)
    }

    /// H1–H4 могут быть в hex (0x1f2e) — приводим к десятичному виду.
    private static func magicHeader(_ value: String?) -> String? {
        guard let value = value?.trimmingCharacters(in: .whitespaces), !value.isEmpty else { return nil }
        let lowercased = value.lowercased()
        if lowercased.hasPrefix("0x") {
            if let number = UInt32(lowercased.dropFirst(2), radix: 16) {
                return String(number)
            }
            return nil
        }
        return value
    }
}
