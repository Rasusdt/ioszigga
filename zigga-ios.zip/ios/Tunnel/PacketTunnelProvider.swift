import Foundation
import NetworkExtension
import WireGuardKit

/// VPN-расширение: поднимает туннель тем же ядром, что и Android-версия — AmneziaWG.
final class PacketTunnelProvider: NEPacketTunnelProvider {
    private var adapter: WireGuardAdapter?

    override func startTunnel(options: [String: NSObject]?, completionHandler: @escaping (Error?) -> Void) {
        guard
            let proto = protocolConfiguration as? NETunnelProviderProtocol,
            let configText = proto.providerConfiguration?["config"] as? String
        else {
            completionHandler(NSError(
                domain: "com.zigga.vpn",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "Не удалось прочитать конфиг"]
            ))
            return
        }

        do {
            let tunnelConfiguration = try WGConfigParser.makeTunnelConfiguration(from: configText)
            let adapter = WireGuardAdapter(with: self) { level, message in
                NSLog("[ZIGGA][%@] %@", String(describing: level), message)
            }
            self.adapter = adapter

            adapter.start(tunnelConfiguration: tunnelConfiguration) { [weak self] error in
                if let error = error {
                    self?.adapter = nil
                    completionHandler(NSError(
                        domain: "com.zigga.vpn",
                        code: 2,
                        userInfo: [NSLocalizedDescriptionKey: "Не удалось включить туннель: \(error)"]
                    ))
                    return
                }
                completionHandler(nil)
            }
        } catch {
            completionHandler(error)
        }
    }

    override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        guard let adapter = adapter else {
            completionHandler()
            return
        }
        adapter.stop { _ in
            self.adapter = nil
            completionHandler()
        }
    }
}
